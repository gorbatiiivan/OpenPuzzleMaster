backgrounds:
https://www.freepik.com/free-photos-vectors/wood-table/7
https://www.freepik.com/search?format=search&query=textures
https://www.freepik.com/search?format=search&page=15&query=textures


online compress:
https://compressjpeg.com/



https://www.freepik.com/free-photo/composed-torn-paper-pieces_1505938.htm#page=15&query=textures&position=46&from_view=search&track=sph